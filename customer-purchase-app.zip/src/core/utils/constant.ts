import { Customer } from "../models/customere-model";

export class Constants {

    public static customerLabels = {
        name: "Name",
        numberOfItems: "# Of Items",
        amount: "Amount",
        action: "Action",
        editButton: "EDIT",
        deleteButton: "DELETE",
        addCustomere: "Add Customer",
        firstName: "First Name",
        lastName: "last Name",
        itemsPurchase: "Items Purchased",
        totalAmount: "Total Amount",
        cancel: "Cancel",
        customerDeatils: "Customer Deatils"
    }

    public static mockCustomerData: Customer[] = [
        { customerId: 1, firstName: 'Abhinav', lastName: 'Singh', countOfPurchase: 3, amountOfItems: 1000 },
        { customerId: 2, firstName: 'Abhay', lastName: 'Singh', countOfPurchase: 5, amountOfItems: 2000 },
        { customerId: 3, firstName: 'Rahul', lastName: 'Singh', countOfPurchase: 8, amountOfItems: 3000 }
    ];
}

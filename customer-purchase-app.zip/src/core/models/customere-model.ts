export interface Customer {
    customerId: number;
    firstName:string;
    lastName:string;
    countOfPurchase: number;
    amountOfItems:number;
}